/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Ahmed
 */

// Java program to create a simple calculator 
// with basic +, -, /, * using java swing elements 

import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.awt.*; 
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javax.swing.*;
import javax.swing.JOptionPane;

import com.sun.xml.internal.txw2.output.ResultFactory;


class Calculator extends JFrame implements ActionListener,SerialPortEventListener { 
	
    
        static JFrame frame; 
        static JPanel panel;
        static JButton oneButton,twoButton,threeButton,fourButton,fiveButton,sixButton,sevenButton,eightButton,nineButton,zeroButton,plusButton,subtractButton,multiplyButton,divisionButton,equalButton,clearButton,floatingButton;
        static JTextField textField; 
        static GridBagConstraints gbc = new GridBagConstraints();
        static JButton buttons[] = new JButton[17];
 
	// store oprerator and operands 
	String s0="", s1="", s2=""; 
	boolean floatflag1=false;
	boolean floatflag=false;
	boolean resultav=false;
	boolean negativeflag=false;
	boolean zeroflag=false;
	//serial port variables
	SerialPort serialPort;
	private static final String PORT_NAMES[] = { 
			"/dev/tty.usbserial-A9007UX1", // Mac OS X
			"/dev/ttyACM0", // Raspberry Pi
			"/dev/ttyUSB0", // Linux
			"COM3", // Windows
	};
	private BufferedReader input;
	/** The output stream to the port */
	private OutputStream output;
	/** Milliseconds to block while waiting for port open */
	private static final int TIME_OUT = 9000;
	/** Default bits per second for COM port. */
	private static final int DATA_RATE = 9600;
	//GUI attributes

	// default constrcutor 
	Calculator() 
	{ 
		s0 = s1 = s2 = ""; 
	} 

	// main function 
	public static void main(String args[]) 
	{ 
	
		// create a frame 
		frame = new JFrame(); 
                // create a panel 
                panel = new JPanel(new GridBagLayout());

		try { 
			// set look and feel 
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
		} 
		catch (Exception e) { 
			
			System.err.println(e.getMessage()); 
		} 

		// create an object of class 
		Calculator c = new Calculator(); 
		
		//initializing the serial port 
		
		c.initialize();
		
		

		// create a textfield 
        textField = new JTextField(16);
		// set the textfield to non editable 
		textField.setEditable(false); 

		// create number buttons 
		zeroButton = new JButton("0"); 
		oneButton = new JButton("1"); 
		twoButton = new JButton("2"); 
		threeButton = new JButton("3"); 
		fourButton = new JButton("4"); 
		fiveButton = new JButton("5"); 
		sixButton = new JButton("6"); 
		sevenButton = new JButton("7"); 
		eightButton = new JButton("8"); 
		nineButton = new JButton("9"); 

		// equals button 
		equalButton = new JButton("="); 

		// create operator buttons 
		plusButton = new JButton("+"); 
		subtractButton = new JButton("-"); 
		divisionButton = new JButton("/"); 
		multiplyButton = new JButton("X"); 
		clearButton = new JButton("C"); 

		// create . button 
		floatingButton = new JButton(".");
                
                buttons[0] = zeroButton;
                buttons[1] = oneButton;
                buttons[2] = twoButton;
                buttons[3] = threeButton;
                buttons[4] = fourButton;
                buttons[5] = fiveButton;
                buttons[6] = sixButton;
                buttons[7] = sevenButton;
                buttons[8] = eightButton;
                buttons[9] = nineButton;
                buttons[10] = plusButton;
                buttons[11] = subtractButton;
                buttons[12] = multiplyButton;
                buttons[13] = divisionButton;
                buttons[14] = equalButton;
                buttons[15] = floatingButton;
                buttons[16] = clearButton;
                
                
                for(JButton b : buttons){
                    b.addActionListener(c);
               }

                
                gbc.insets = new Insets(3,3,3,3);
                gbc.ipady = 30;
                gbc.ipadx = 20;
                
		// add elements to panel 
		gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.gridwidth = 5;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                textField.setFont(new Font(Font.SERIF, Font.BOLD,  16));
                textField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                panel.add(textField,gbc);

                gbc.fill = GridBagConstraints.CENTER;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 0;
                gbc.gridy = 2;
                nineButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(nineButton,gbc);
                
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 1;
                gbc.gridy = 2;
                eightButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(eightButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 2;
                gbc.gridy = 2;
                sevenButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(sevenButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 3;
                gbc.gridy = 2;
                plusButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(plusButton,gbc);

                gbc.gridx = 4;
                gbc.gridy = 2;
                gbc.gridheight = 2;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.VERTICAL;
                clearButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(clearButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 0;
                gbc.gridy = 3;
                gbc.fill = GridBagConstraints.CENTER;
                sixButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(sixButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 1;
                gbc.gridy = 3;
                fiveButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(fiveButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 2;
                gbc.gridy = 3;
                fourButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(fourButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 3;
                gbc.gridy = 3;
                subtractButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(subtractButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 0;
                gbc.gridy = 4;
                threeButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(threeButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 1;
                gbc.gridy = 4;
                twoButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(twoButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 2;
                gbc.gridy = 4;
                oneButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(oneButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 3;
                gbc.gridy = 4;
                multiplyButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(multiplyButton,gbc);

                gbc.gridx = 4;
                gbc.gridy = 4;
                gbc.gridheight = 2;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.VERTICAL;
                equalButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(equalButton,gbc);

                gbc.gridx = 0;
                gbc.gridy = 5;
                gbc.gridheight = 1;
                gbc.gridwidth = 2;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                zeroButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(zeroButton,gbc);

                gbc.gridx = 2;
                gbc.gridy = 5;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                floatingButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(floatingButton,gbc);

                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.gridx = 3;
                gbc.gridy = 5;
                divisionButton.setFont(new Font(Font.SERIF, Font.BOLD,  13));
                panel.add(divisionButton,gbc);

		// set Background of panel 
		panel.setBackground(new Color(48,56,66));

		// add panel to frame 
		frame.setTitle("Calculator");
                frame.setSize(380,380);
                frame.setResizable(false);
                frame.setVisible(true);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                for(JButton b : buttons){
                    b.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        b.setBackground(new Color (255,255,255));
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        b.setBackground(UIManager.getColor("control"));
                    }
                  });
                 }
                frame.add(panel);
                
                JOptionPane.showMessageDialog(null, "Info: The application might close if the hardware is disconnected while running the software. In this case, kindly reconnect the hardware and run the application again");
    			return;
		
	} 
	//the logic of the calculator that handles the serial and the port 
	public void CalculatorHandler(String s) throws Exception {


		if ((s.charAt(0) >= '0' && s.charAt(0) <= '9') || ((s.charAt(0) == '.')||(s.charAt(0)=='-')&&!negativeflag && s2.equals(""))) {
			if((s2.equals("") && s0.equals("0") && s.charAt(0)=='0')|| (!s1.equals("") && s.charAt(0)=='0' &&  s2.equals("0"))) {
				
			}else {
			// if operand is present then add to second no
			if(s.charAt(0)=='-'){
				negativeflag=true;
			}else{
				negativeflag=false;
			}
			if(s.charAt(0)=='.'){
				if (resultav) {
					s0="0.";
					s1=s2="";
					floatflag=true;
					resultav=false;
				}
				if (!s0.contains(".") || (!s2.equals("") && !s2.contains(".")) || (!s1.equals("")&&s2.equals("")) ){
				for(int i=0;i<s0.length();i++){
					if(s0.charAt(i)=='.')
						floatflag=true;
					else
						floatflag=false;
				}
				for(int i=0;i<s2.length();i++){
					if(s2.charAt(i)=='.')
						floatflag1=true;
					else
						floatflag1=false;
				}
				if (!s1.equals("")){
					if(!floatflag1){
						s2=s2+s;
						floatflag1=true;
					}
				}else{
					if(!floatflag){
						if(resultav){
							s0 =s;
							floatflag=true;
							resultav=false;
						}else{
							s0 =s0+s;   
							floatflag=true;
							resultav=false;
						}
					}
				}
				}}else{
				if (!s1.equals("")) {
					if(s2.contains(".")) {
						if(s.equals("-")) {
							negativeflag=false;
						}else {
							s2 = s2 + s;
						}
					}else{
						if (s.equals("-")&& !s2.equals("")) {

						}else {s2 = s2 + s;}
					}


				}else{
					if((!s0.equals(""))&&resultav){
						if(s.equals("-")) {
							s1=s;
						}else {
							s0=s;
						}
						resultav=false;
					}else{
						if(!s0.equals("")) {
							if(s.equals("-") && s0.charAt(s0.length()-1)!='.') {
								s1=s;
							}else {
								if(s.equals("-")&& s0.charAt(s0.length()-1)=='.') {
									//System.out.println(s);
									negativeflag=false;
								}else {

									s0=s0+s;}
							}
						}else {

							s0=s0+s;
						}
					}

				} 
			} 
			// set the value of text 
			textField.setText(s0 + s1 + s2); 
		}
		}else if (s.charAt(0) == 'C') { 
			// clear the one letter 
			s0 = s1 = s2 = ""; 
			// set the value of text 
			textField.setText(s0 + s1 + s2);
			floatflag=false;
			floatflag1=false;
			resultav=false;
			negativeflag=false;
		}else if (s.charAt(0) == '=') {
			negativeflag=false;
			double te=0; 
			// store the value in 1st
			switch (s1) {
			case "+":
				te = (Double.parseDouble(s0) + Double.parseDouble(s2));
				if(te==-0.0){
					te=0;
				}
				// set the value of text
				textField.setText(s0 + s1 + s2 + "=" + te);
				// convert it to string
				s0 = Double.toString(te);
				s1 = s2 = "";
				resultav=true;
				break;
			case "-":
				te = (Double.parseDouble(s0) - Double.parseDouble(s2));
				// set the value of text
				if(te==-0.0){
					te=0;
				}
				textField.setText(s0 + s1 + s2 + " = " + te);
				// convert it to string
				s0 = Double.toString(te);
				s1 = s2 = "";
				resultav=true;
				break;
			case "/":
				te = (Double.parseDouble(s0) / Double.parseDouble(s2));
				// set the value of text
				if(te==-0.0){
					te=0;
				}
				textField.setText(s0 + s1 + s2 + " = " + te);
				// convert it to string
				s0 = Double.toString(te);
				s1 = s2 = "";
				resultav=true;
				break;
			case "X":
				te = (Double.parseDouble(s0) * Double.parseDouble(s2));
				// set the value of text
				if(te==-0.0){
					te=0;
				}
				textField.setText(s0 + s1 + s2 + " = " + te);
				// convert it to string
				s0 = Double.toString(te);
				s1 = s2 = "";
				resultav=true;
				break;
			default:
				break;
			}
		}else{ 
			if ((s2.equals("")&&s0.charAt(s0.length()-1)=='.') || (!s2.equals("")&& s2.charAt(s2.length()-1)=='.') ) {
				
			}else {
			// if there was no operand 
			if ((s1.equals("") && s2.equals(""))&&(!s0.equals(""))&&!s0.equals("-")) {
				s1 = s; }
			// else evaluate 
			else { 
				double te; 
				// store the value in 1st 
				if (s1.equals("+")) 
					te = (Double.parseDouble(s0) + Double.parseDouble(s2)); 
				else if (s1.equals("-")) 
					te = (Double.parseDouble(s0) - Double.parseDouble(s2)); 
				else if (s1.equals("/")) 
					te = (Double.parseDouble(s0) / Double.parseDouble(s2)); 
				else
					te = (Double.parseDouble(s0) * Double.parseDouble(s2)); 
				// convert it to string 
				s0 = Double.toString(te); 
				// place the operator 
				s1 = s; 
				// make the operand blank 
				s2 = ""; 
			} }
			// set the value of text 
			textField.setText(s0 + s1 + s2); 
		}  
	}
	public void actionPerformed(ActionEvent e) 
	{ 
		try {
			CalculatorHandler(e.getActionCommand());
		} catch (Exception ex) {

			//expected action of an empty string
		}

	}
	public void initialize() {
		// the next line is for Raspberry Pi and 
		// gets us into the while loop and was suggested here was suggested https://www.raspberrypi.org/phpBB3/viewtopic.php?frame=81&t=32186
		// System.setProperty("gnu.io.rxtx.SerialPorts", "COM3");
		CommPortIdentifier portId = null;
		Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

		//First, Find an instance of serial port as set in PORT_NAMES.
		while (portEnum.hasMoreElements()) {
			CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();
			for (String portName : PORT_NAMES) {
				if (currPortId.getName().equals(portName)) {
					portId = currPortId;
					break;
				}
			}
		}
		if (portId == null) {
			//System.out.println("Could not find COM port.");
                        JOptionPane.showMessageDialog(null, "\t WARNING \n Arduino is not connected! \n You will be using calculator software only!");
			return;
		}

		try {
			// open serial port, and use class name for the appName.
			serialPort = (SerialPort) portId.open(this.getClass().getName(),
					TIME_OUT);

			// set port parameters
			serialPort.setSerialPortParams(DATA_RATE,
					SerialPort.DATABITS_8,
					SerialPort.STOPBITS_1,
					SerialPort.PARITY_NONE);

			// open the streams
			input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));
			output = serialPort.getOutputStream();

			// add event listeners
			serialPort.addEventListener(this);
			serialPort.notifyOnDataAvailable(true);
			
		} catch (Exception e) {
		
			System.err.println(e.toString());
		}
	}
	public synchronized void close() {
		
		if (serialPort != null) {
			
			serialPort.removeEventListener();
			serialPort.close();
		}
	}
	public void Highlight(String inputLine){
		try{
			switch (inputLine.charAt(0)) {
			case '0':
				zeroButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				zeroButton.setBackground(UIManager.getColor("control"));
				break;
			case '1':
				oneButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				oneButton.setBackground(UIManager.getColor("control"));
				break;
			case '2':
				twoButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				twoButton.setBackground(UIManager.getColor("control"));
				break;
			case '3':
				threeButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				threeButton.setBackground(UIManager.getColor("control"));
				break;
			case '4':
				fourButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				fourButton.setBackground(UIManager.getColor("control"));
				break;
			case '5':
				fiveButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				fiveButton.setBackground(UIManager.getColor("control"));
				break;
			case '6':
				sixButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				sixButton.setBackground(UIManager.getColor("control"));
				break;
			case '7':
				sevenButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				sevenButton.setBackground(UIManager.getColor("control"));
				break;
			case '8':
				eightButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				eightButton.setBackground(UIManager.getColor("control"));
				break;
			case '9':
				nineButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(200);
				nineButton.setBackground(UIManager.getColor("control"));
				break;
			case '=':
				equalButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				equalButton.setBackground(UIManager.getColor("control"));
				break;
			case 'X':
				multiplyButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				multiplyButton.setBackground(UIManager.getColor("control"));
				break;
			case '-':
				subtractButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				subtractButton.setBackground(UIManager.getColor("control"));
				break;
			case '+':
				plusButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				plusButton.setBackground(UIManager.getColor("control"));
				break;    
			case '/':
				divisionButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				divisionButton.setBackground(UIManager.getColor("control"));
				break;
			case 'c':
				clearButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				clearButton.setBackground(UIManager.getColor("control"));
				break;
			case '.':
				floatingButton.setBackground(new Color (0,100,200));
				TimeUnit.MILLISECONDS.sleep(100);
				floatingButton.setBackground(UIManager.getColor("control"));
				break;    
			default:
				break;
			}
		}catch(Exception ex){
			
		}
	}
	/**
	 * Handle an event on the serial port. Read the data 
	 */
	public synchronized void serialEvent(SerialPortEvent oEvent) {	
		if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
			try {
				String inputLine;
				inputLine=input.readLine();
				Highlight(inputLine);
				CalculatorHandler(inputLine);
			}
			catch (Exception e) {
				//expected action of an empty string
			}
		}		
	}
}

